A Pen created at CodePen.io. You can find this one at http://codepen.io/ejsado/pen/HLgzK.

 My attempt at making Google Charts look better. If anyone figures out an easy way to style them with CSS, let me know.